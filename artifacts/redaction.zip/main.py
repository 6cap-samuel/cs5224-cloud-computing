def lambda_handler(event, ctx):
    return event
